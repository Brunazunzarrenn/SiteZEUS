$(document).ready(function() {
  $('.menu-btn ion-icon').click(function(){
$('.navbar .menu').toggleClass("active");
$('.menu-btn i').toggleClass("active");
});
  $(window).scroll(function() {
    if (this.scrollY > 20) {
      $('.navbar').addClass("sticky");
    } else {
      $('.navbar').removeClass("sticky");
    }
    if (this.scrollY > 500) {
      $('.scroll-up-btn').addClass("show");
    } else {
      $('.scroll-up-btn').removeClass("show");
    }
  });
  $('.menu-btn').click(function() {
    let component = $('.scroll-up-btn');
    component.addClass("show");
  });


  var typed = new Typed(".typing", {
    strings: ["Força", "Raça", "Determinação", "Deus dos raios"],
    typeSpeed: 100,
    backSpeed: 60,
    loop: true
  });


  $('.menu-btn').click(function() {
    $('.navbar .menu').toggleClass("active");
    $('.menu-btn i').toggleClass("active");
  });
  


  $('.carousel').owlCarousel({
    margin: 20,
    loop: true,
    autoplayTimeOut: 2000,
    autoplayHoverPauser: true,
    responsive: {
      0: {
        items: 1,
        nav: false
      },
      600: {
        items: 2,
        nav: false
      },
      1000: {
        items: 3,
        nav: false
      }
    }
  });
});

var radio = document.querySelector('.manual-btn')
var cont = 1

document.getElementById('radio1').checked = true

setInterval(() => {
  proximaImg()
}, 5000)

function proximaImg() {
  cont++

  if (cont > 3) {
    cont = 1
  }

  document.getElementById('radio' + cont).checked = true
}